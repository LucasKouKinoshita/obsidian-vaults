- Estritamente sequenciais
- Estrutura:
![[Pasted image 20250405155719.png]]
	Todas as fases geram documentação detalhjada

- Natural, visto que projetos de engenharia tradicional são sequenciais e precedidos de planejamento detalhado.
- Muitas vezes inadequado pois a elaboração de um software, produto desta área da engenharia, possui características únicas.
	- O que ficou claro devido a problemas frequentes no método waterfall
		- Cronogramas e orçamentos não eram obedecidos 
			- 55% estouravam os prazos entre 51% e 200%, 12% estouram os prazos acima de 200%
			- 40% ultrapassa o orçamento entre 51% e 200%
		- Cancelamento de projetos sem entregar sistemas funcionais
		