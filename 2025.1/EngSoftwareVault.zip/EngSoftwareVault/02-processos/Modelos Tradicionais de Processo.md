
"Em 2001, um grupo de profissionais da indústria se reuniu na cidade de
Snowbird, no estado norte-americano de Utah, para discutir e propor uma
alternativa aos processos do tipo [[Waterfall]] que então predominavam.
Essencialmente, eles passaram a defender que software é diferente de
produtos tradicionais de Engenharia. Por isso, software também demanda
um processo de desenvolvimento diferente."

- Mudanças frequentes de requisitos
- Ideias imprecisas/ pouco claras durante requisição do produto
- Muito mutável

Surgimento do [[Manifesto Ágil]]


