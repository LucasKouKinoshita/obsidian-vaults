"Testes A/B (ou split tests) são usados para escolher, dentre duas versões de
um sistema, aquela que desperta maior interesse dos usuários. As duas
versões são idênticas, exceto que uma implementa um requisito A e outra
implementa um requisito B, sendo que A e B são mutuamente exclusivos"