Os requisitos devem ser priorizados
- Nem sempre o que é especificado pelo cliente será implementado nas releases iniciais
- Requisitos podem mudar 
	- O documento, caso exista, também deve ser atualizado
- Rastreávesi (traceability)
	- Devemos conseguir identificar qual requisito é implementado por cada trecho de código e vice-versa