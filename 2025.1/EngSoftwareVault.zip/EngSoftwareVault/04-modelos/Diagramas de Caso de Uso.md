"Esse diagrama é um índice gráfico de
casos de uso. Ele representa os atores de um sistema (como pequenos
bonecos) e os casos de uso (como elipses). Mostram-se também dois tipos de
relacionamento: (1) ligando ator com caso de uso, que indicam que um ator
participa de um determinado caso de uso; (2) ligando dois casos de uso, que
indicam que um caso de uso inclui ou estende outro caso de uso"

![[Pasted image 20250406215508.png]]